<div align="center">
  <img src="./extra/logo/velacritty-term.svg" alt="Velacritty Logo" width="200"/>

  # Velacritty

  **A fast, cross-platform, OpenGL terminal emulator with enhanced viewport control**

  [![License: Apache 2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE-APACHE)
  [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE-MIT)

  [Installation](#installation) • [Features](#features) • [Configuration](#configuration) • [FAQ](#faq)

</div>

---

## 🎯 What is Velacritty?

**Velacritty** is a high-performance GPU-accelerated terminal emulator forked from **[Alacritty](https://github.com/alacritty/alacritty)**, enhanced with **advanced viewport control**, **background image support**, and **improved TUI application compatibility**. It maintains Alacritty's legendary speed while adding power-user features for those who need precise control over terminal scrolling behavior.

**TL;DR**: Alacritty + Viewport Lock (for TUI apps) + Background Images + WSL2 Resilience

---

## ⚡ Why Velacritty?

### The Problem with Traditional Terminals

Most terminals (including Alacritty) automatically scroll to the bottom when new output arrives. This breaks TUI applications:

- Running `htop` while reviewing scrollback? **Viewport jumps constantly** 🤦
- Using `vim` in the terminal? **Auto-scroll disrupts your workflow** 😤
- Monitoring with `btop`/`gotop`? **Can't browse history while it's running** 😞

### Velacritty's Solution

**Complete Viewport Lock System** — When enabled, viewport stays *completely locked* even when new output arrives:

```toml
[scrolling]
auto_scroll = false  # Viewport never auto-scrolls, even at bottom
```

**Now you can:**
- ✅ Run `htop` while reviewing scrollback history
- ✅ Edit files in `vim` without viewport disruption  
- ✅ Monitor system stats with `btop` while browsing logs
- ✅ Maintain static TUI dashboards without interference

**Plus**: GPU-accelerated background images, enhanced WSL2 stability, and all of Alacritty's performance.

---

## 🏗️ What Makes Velacritty Different

### 1. **Complete Viewport Lock** *(Unique to Velacritty)*

**The Innovation**: Three-phase architecture (config → grid state → event handling) that completely disables automatic scroll-to-bottom behavior when `scrolling.auto_scroll = false`.

**Technical Details**:
- User-initiated scrolling (keybindings, mouse wheel) still works perfectly
- Vi mode scrolling remains fully functional
- Zero performance impact when disabled
- Backward compatible (default: `auto_scroll = true` matches upstream)

**Use Cases**:
- System monitoring: `htop`, `btop`, `gotop`, `nvtop`
- Text editors: `vim`, `neovim`, `nano`, `emacs -nw`
- File managers: `ranger`, `nnn`, `lf`
- Interactive tools: `cmus`, `ncmpcpp`, custom dashboards

---

### 2. **GPU-Accelerated Background Images** *(Unique to Velacritty)*

Full-featured background rendering with zero CPU overhead:

```toml
[window.background]
path = "~/Pictures/terminal-bg.png"
opacity = 0.3  # 0.0 = fully transparent, 1.0 = opaque
scaling = "fill"  # fit, fill, center, tile, stretch
```

**Features**:
- Formats: PNG, JPEG
- Path types: Absolute (`/path/to/image.png`), home (`~/Pictures/`), relative (`./bg.png`)
- Scaling modes: fit, fill, center, tile, stretch
- Independent opacity control (separate from window opacity)
- Hot-reload on config change
- Early validation with helpful warnings

---

### 3. **Enhanced WSL2 Resize Resilience** *(Velacritty Research)*

Three-phase fix for WSL2 terminal resize crashes:

1. **Debouncing**: Rate-limit resize events (50ms cooldown)
2. **Error Handling**: Graceful recovery from ConPTY failures
3. **Overflow Protection**: Safe arithmetic for extreme dimensions

**Result**: Rock-solid stability on WSL2 even with aggressive window resizing.

📄 See [`docs/WSL2_RESIZE_FIX.md`](docs/WSL2_RESIZE_FIX.md) for technical details.

---

## 🚀 Installation

### Requirements

- **Rust**: 1.70.0 or higher
- **OpenGL**: ES 2.0 or higher
- **Windows**: ConPTY support (Windows 10 version 1809+)

### Build from Source

```bash
# Clone the repository
git clone https://github.com/CoderDayton/velacritty.git
cd velacritty

# Build release binary
cargo build --release

# Binary location: target/release/velacritty
./target/release/velacritty
```

### Platform-Specific Instructions

For detailed installation including dependencies, desktop integration, and package managers, see **[INSTALL.md](INSTALL.md)**.

---

## ✨ Features

### Inherited from Alacritty (Full Credit to Upstream)

- **GPU-accelerated rendering** — OpenGL for buttery-smooth 60+ FPS
- **Cross-platform** — Linux, BSD, macOS, Windows
- **Vi mode** — Keyboard-driven text selection and navigation
- **Search** — Regex support with highlighting
- **True color** — 24-bit color support
- **Ligatures** — Programming font ligatures (FiraCode, JetBrains Mono)
- **Clickable URLs** — Ctrl+Click to open in browser
- **Configurable keybindings** — Full customization via TOML
- **IPC messaging** — `velacritty msg` for runtime control

### Enhanced in Velacritty

- ✅ **Complete viewport lock** — Disable auto-scroll for TUI apps
- ✅ **Background images** — GPU-accelerated with opacity control
- ✅ **WSL2 stability** — Enhanced resize handling
- ✅ **Config hot-reload** — Changes apply instantly
- 🔄 *(More features in development — see [ROADMAP.md](docs/ROADMAP.md))*

For complete feature documentation, see **[docs/features.md](docs/features.md)**.

---

## ⚙️ Configuration

### Config File Locations

**Linux/BSD/macOS:**
1. `$XDG_CONFIG_HOME/velacritty/velacritty.toml`
2. `$XDG_CONFIG_HOME/velacritty.toml`
3. `$HOME/.config/velacritty/velacritty.toml`
4. `$HOME/.velacritty.toml`

**Windows:**
- `%APPDATA%\velacritty\velacritty.toml`

> **Backward Compatibility**: Velacritty also reads from Alacritty config paths (`~/.config/alacritty/alacritty.toml`) for seamless migration.

### Example Configuration

```toml
# Velacritty Configuration Example

[window]
opacity = 0.95

[window.background]
path = "~/Pictures/terminal-bg.png"
opacity = 0.3
scaling = "fill"

[scrolling]
auto_scroll = false  # Enable viewport lock for TUI apps

[font]
size = 12.0

[font.normal]
family = "FiraCode Nerd Font"
style = "Regular"
```

### Default Behavior Changes

Velacritty identifies itself with its own branding:

| Setting | Alacritty | Velacritty |
|---------|-----------|------------|
| Window title | "Alacritty" | "Velacritty" |
| Window class | `Alacritty` | `Velacritty` |

**If you use window manager rules** (i3, sway, Hyprland), update them to match `Velacritty`. See **[MIGRATION.md](MIGRATION.md)** for detailed instructions.

To keep the original "Alacritty" branding:
```toml
[window]
title = "Alacritty"

[window.class]
general = "Alacritty"
instance = "Alacritty"
```

For full configuration documentation, see `man 5 velacritty` or [Alacritty's config docs](https://alacritty.org/config-alacritty.html) (same format).

---

## 🤝 Contributing

Contributions are welcome! Please see **[CONTRIBUTING.md](CONTRIBUTING.md)** for guidelines.

**Before submitting**:
1. Open an issue to discuss significant changes
2. Follow existing code style (run `cargo fmt`)
3. Add tests for new features
4. Update documentation as needed

---

## 📚 FAQ

### **What's the relationship between Velacritty and Alacritty?**

Velacritty is a fork that adds power-user enhancements while maintaining Alacritty's performance. We regularly sync with upstream to incorporate bug fixes and new features.

**All core functionality** (terminal emulation, rendering, platform support) is credited to the Alacritty maintainers and contributors.

---

### **Can I use my existing Alacritty config?**

**Yes!** Velacritty uses the same TOML format and reads from Alacritty config paths for compatibility.

**Migration steps**:
1. Copy config: `cp ~/.config/alacritty/alacritty.toml ~/.config/velacritty/velacritty.toml`
2. Update window manager rules (if used) — see [MIGRATION.md](MIGRATION.md)
3. Done! (2 minutes)

**Note**: Default window title/class are now "Velacritty" instead of "Alacritty".

---

### **Is it as fast as Alacritty?**

**Yes** — Velacritty inherits Alacritty's GPU-accelerated rendering architecture unchanged. The viewport lock and background features have zero performance impact when disabled.

**Benchmarks**: Same 60+ FPS rendering, <100ms startup time.

---

### **Why fork instead of contributing upstream?**

Velacritty explores features that diverge from Alacritty's minimalist philosophy:

- **Viewport Lock**: Alacritty considers auto-scroll fundamental to terminal UX
- **Background Images**: Alacritty delegates to compositor (external solution)

We deeply respect Alacritty's focused approach and created this fork to experiment with power-user features while maintaining the option to contribute appropriate improvements back upstream (e.g., WSL2 fixes may be upstreamed).

---

### **What's coming next?**

See **[docs/ROADMAP.md](docs/ROADMAP.md)** for planned features:
- Background animation support (GIF/video)
- Advanced scrolling modes (smooth scrolling, inertia)
- Additional color scheme presets
- Performance profiling tools

---

## 🔄 Feature Comparison

| Feature | Alacritty | Velacritty |
|---------|-----------|------------|
| GPU Rendering | ✅ | ✅ (Identical) |
| Vi Mode / Search | ✅ | ✅ (Identical) |
| True Color / Ligatures | ✅ | ✅ (Identical) |
| Cross-Platform | ✅ | ✅ (Identical) |
| **Viewport Lock (TUI)** | ❌ | ✅ **UNIQUE** |
| **Background Images** | ❌ | ✅ **UNIQUE** |
| **WSL2 Resilience** | ⚠️ | ✅ **Enhanced** |
| Config Hot-Reload | ✅ | ✅ (Identical) |
| IPC (`msg` command) | ✅ | ✅ (Identical) |

---

## 🎯 Who Should Use Velacritty?

### **Perfect For:**
- Power users who run TUI monitoring tools (`htop`, `btop`, `gotop`)
- Developers using terminal editors (`vim`, `neovim`, `emacs -nw`)
- System administrators who need precise scrollback control
- Users who want background aesthetics without performance loss
- Anyone who loves Alacritty but needs "just a bit more control"

### **Not For:**
- Users who want tabbed terminals → Use `tmux`/`zellij` instead
- Users who want built-in multiplexing → Use terminal multiplexers
- Users preferring traditional terminals → Use `gnome-terminal`/`kitty`

---

## 📜 License

Velacritty is dual-licensed:

- **Apache License, Version 2.0** ([LICENSE-APACHE](LICENSE-APACHE))
- **MIT License** ([LICENSE-MIT](LICENSE-MIT))

You may choose either license for your use.

### Attribution

```
Velacritty: Copyright © 2025 Dayton Dunbar
Alacritty (base): Copyright © 2020 The Alacritty Project
```

All core terminal emulation, rendering, and platform support is credited to the [Alacritty maintainers and contributors](https://github.com/alacritty/alacritty/graphs/contributors).

See **[NOTICE](NOTICE)** for complete attribution details.

---

## 🔗 Resources

- **Repository**: https://github.com/CoderDayton/velacritty
- **Issue Tracker**: https://github.com/CoderDayton/velacritty/issues
- **Original Alacritty**: https://github.com/alacritty/alacritty
- **Alacritty Website**: https://alacritty.org
- **Documentation**: [docs/](docs/)

---

## 📖 Further Reading

**About Alacritty** (the foundation of Velacritty):
- [Announcing Alacritty, a GPU-Accelerated Terminal Emulator](https://jwilm.io/blog/announcing-alacritty/) — January 6, 2017
- [A talk about Alacritty at the Rust Meetup](https://www.youtube.com/watch?v=qHOdYO3WUTk) — January 19, 2017
- [Alacritty Lands Scrollback, Publishes Benchmarks](https://jwilm.io/blog/alacritty-lands-scrollback/) — September 17, 2018

---

<div align="center">

**Built with ❤️ by [Dayton Dunbar](https://github.com/CoderDayton)**  
**Based on the exceptional [Alacritty](https://github.com/alacritty/alacritty) terminal emulator**

*"Alacritty's speed, with the control you need."*

</div>
